public class FileEmptyException extends Exception{
    public FileEmptyException(String errMessage) {
        super(errMessage);
    }
}
