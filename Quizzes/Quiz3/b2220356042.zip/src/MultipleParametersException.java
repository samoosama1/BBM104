public class MultipleParametersException extends Exception{
    public MultipleParametersException(String errMessage) {
        super(errMessage);
    }
}
