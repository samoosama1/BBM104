public class InvalidCharException extends Exception{
    public InvalidCharException(String errMessage) {
        super(errMessage);
    }
}

