public interface DepartureController {
    void DepartureSchedule(TripSchedule tripSchedule);
}
