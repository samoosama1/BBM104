public interface ArrivalController {
    void ArrivalSchedule(TripSchedule tripSchedule);
}
