public interface Prompter {
    void prompt();
}