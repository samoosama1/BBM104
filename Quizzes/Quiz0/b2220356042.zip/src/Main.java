public class Main {
	public static void main(String[] args) {
		System.out.println("Hello, World! My name is Abdussamet TEKIN. This is my first Java Code that I submit during BBM 104 Spring 2023 Term.");
	}
}

